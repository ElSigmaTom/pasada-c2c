"""Hand-routed native KiCad 7 schematics. No image generation or autorouting."""
from __future__ import annotations
import copy, csv, json, math, os, subprocess, uuid
from pathlib import Path
import sexpdata as sx

ROOT=Path(__file__).resolve().parent
_lib_candidates=[Path(os.environ[k]) for k in ['KICAD_SYMBOL_DIR','KICAD9_SYMBOL_DIR','KICAD8_SYMBOL_DIR','KICAD7_SYMBOL_DIR'] if os.environ.get(k)]
_lib_candidates += [Path('/usr/share/kicad/symbols'),ROOT.parent/'kicad_runtime/usr/share/kicad/symbols']
LIB=next((p for p in _lib_candidates if p.is_dir()),_lib_candidates[-1])
G=2.54
S=sx.Symbol
def n(tag,*args): return [S(tag),*args]
def u(): return str(uuid.uuid4())
def mm(v): return round(v*G,6)
def fx(size=1.27,justify=None,hide=False):
    a=n('effects',n('font',n('size',size,size)))
    if justify: a.append(n('justify',S(justify)))
    if hide: a.append(S('hide'))
    return a
def item(a,key): return next((v for v in a if isinstance(v,list) and v[0]==S(key)),None)
def val(a,key,default=None):
    t=item(a,key);return t[1] if t else default
LIBCACHE={}
def standard(lib,name):
    if lib not in LIBCACHE:
        raw=sx.loads((LIB/(lib+'.kicad_sym')).read_text())
        LIBCACHE[lib]={x[1]:x for x in raw if isinstance(x,list) and x[0]==S('symbol')}
    raw=copy.deepcopy(LIBCACHE[lib][name])
    parent=val(raw,'extends')
    if parent:
        base=standard(lib,parent)
        old=base[1].split(':')[-1]
        base[1]=name
        for part in base:
            if isinstance(part,list) and part[0]==S('symbol'):
                part[1]=part[1].replace(old+'_',name+'_',1)
        for prop in [x for x in raw if isinstance(x,list) and x[0]==S('property')]:
            base=[x for x in base if not(isinstance(x,list) and x[0]==S('property') and x[1]==prop[1])]
            base.append(prop)
        raw=base
    raw[1]=lib+':'+name
    return raw

def module(name,w,h,pins,description='',datasheet=''):
    """Pins: (number, name, x, y, angle, type), local y positive UP, in grid units."""
    root=n('symbol','PASADA:'+name,n('pin_names',n('offset',1.016)),
           n('in_bom',S('yes')),n('on_board',S('yes')))
    for i,(key,value) in enumerate([('Reference','U'),('Value',name),('Footprint',''),('Datasheet',datasheet),('Description',description)]):
        root.append(n('property',key,value,n('id',i),n('at',0,0,0),fx(hide=i>=2)))
    root.append(n('symbol',name+'_0_1',n('rectangle',n('start',mm(-w/2),mm(h/2)),
                  n('end',mm(w/2),mm(-h/2)),n('stroke',n('width',.254),n('type',S('default'))),
                  n('fill',n('type',S('background'))))))
    unit=n('symbol',name+'_1_1')
    for number,pname,x,y,angle,etype in pins:
        unit.append(n('pin',S(etype),S('line'),n('at',mm(x),mm(y),angle),n('length',mm(3)),
            n('name',pname,fx(1.8)),n('number',str(number),fx(1.4))))
    root.append(unit)
    return root

def supermini(usb=False):
    left=['5V','GND','3V3','4','3','2','1','0']
    right=['5','6','7','8','9','10','20','21']
    pins=[]
    for side,numbers in [('L',left),('R',right)]:
        for i,p in enumerate(numbers):
            et='bidirectional'
            if p in ['5V','3V3']: et='power_out' if usb else 'power_in'
            if p=='GND': et='power_in'
            label=p if p in ['5V','GND','3V3'] else 'GPIO'+p
            pins.append((p,label,-13 if side=='L' else 13,10.5-3*i,0 if side=='L' else 180,et))
    return module('C3_SuperMini_USB' if usb else 'C3_SuperMini_EXT3V3',20,27,pins,
        'ESP32-C3 SuperMini board; pin IDs are header silkscreen, not chip pad numbers. Verify actual board variant.')

CUSTOM={}
def customdefs():
    a=[supermini(False),supermini(True)]
    a.append(module('CN3065_carrier',16,14,[
        ('IN+','IN+',-11,2,0,'power_in'),('IN-','IN-',-11,-3,0,'passive'),
        ('BAT+','BAT+',11,2,180,'passive'),('BAT-','BAT-',11,-3,180,'passive')],
        'Purchased CN3065 carrier functional terminals; board pad order and ISET/TEMP implementation require inspection.',
        'https://files.seeedstudio.com/wiki/Lipo_Rider_Pro/res/DSE-CN3065.pdf'))
    a.append(module('Protection_1S_common_port',16,14,[
        ('P+','P+',-11,2,0,'passive'),('P-','P-',-11,-3,0,'passive'),
        ('B+','B+',11,2,180,'passive'),('B-','B-',11,-3,180,'passive')],
        'Optional 1S common-port protection; all load/charger returns use P-, not B-.'))
    a.append(module('TPS63020_carrier',16,14,[
        ('IN+','IN+',-11,2,0,'power_in'),('IN-','IN-',-11,-3,0,'passive'),
        ('OUT+','OUT+',11,2,180,'power_out'),('OUT-','OUT-',11,-3,180,'passive'),
        ('EN','EN*',0,-10,90,'input')],
        'Populated 3.3 V buck-boost module. EN* only after accessible pad and fixed enable link are verified.',
        'https://www.ti.com/lit/ds/symlink/tps63020.pdf'))
    a.append(module('MMC5603_breakout',18,14,[
        ('VIN','VIN',0,10,270,'power_in'),('GND','GND',0,-10,90,'power_in'),
        ('SDA','SDA',-12,2,0,'bidirectional'),('SCL','SCL',-12,-1,0,'input'),
        ('3Vo','3Vo',12,2,180,'power_out')],
        'PCBfun selected carrier; terminal IDs by function/silkscreen. 3Vo is an output, not the power input.',
        'https://learn.adafruit.com/adafruit-mmc5603-triple-axis-magnetometer/pinouts'))
    a.append(module('Ultimate_GPS_v3',20,21,[
        ('2','VIN',0,13.5,270,'power_in'),('3','GND',0,-13.5,90,'power_in'),
        ('5','TX',-13,4.5,0,'output'),('4','RX',-13,1.5,0,'input'),
        ('1','1PPS',13,7.5,180,'output'),('6','FIX',13,4.5,180,'output'),
        ('7','VBAT',13,1.5,180,'power_in'),('8','EN',13,-1.5,180,'input'),
        ('9','3.3V_OUT',13,-4.5,180,'power_out')],
        'Proposed Adafruit Ultimate GPS v3 #746. Pin numbers are JP1 from manufacturer Eagle CAD; onboard patch antenna/regulator.',
        'https://learn.adafruit.com/adafruit-ultimate-gps/pinouts'))
    # DS3231SN SOIC-16 pin numbering is from the Analog Devices datasheet.
    rtc=[('2','VCC',-2,16,270,'power_in'),('14','VBAT',2,16,270,'power_in'),
         ('13','GND',0,-16,90,'power_in'),('1','32kHz',10,9,180,'open_collector'),
         ('3','INT/SQW',10,6,180,'open_collector'),('4','RST',10,3,180,'open_collector'),
         ('16','SCL',10,-7.5,180,'input'),('15','SDA',10,-10.5,180,'bidirectional')]
    for i,p in enumerate(range(5,13)): rtc.append((str(p),'NC_to_GND',-10,10-2*i,0,'passive'))
    a.append(module('DS3231SN',14,26,rtc,'Proposed bare SOIC-16 RTC on adapter. Pins 5-12 MUST be grounded; no battery charging circuit.',
        'https://www.analog.com/media/en/technical-documentation/data-sheets/DS3231.pdf'))
    # A real numbered 4-way logic service connector, not a cabinet power interface.
    a.append(module('Logic_port_4',8,13,[('1','3V3',-7,4.5,0,'passive'),
        ('2','GND',-7,1.5,0,'passive'),('3','TX',-7,-1.5,0,'passive'),('4','RX',-7,-4.5,0,'passive')]))
    return {x[1]:x for x in a}
CUSTOM=customdefs()

class Sheet:
    def __init__(self,name,title):
        self.name=name;self.title=title;self.id=u();self.parts={};self.defs={};self.objects=[];self.used=set();self.dots=set()
    def definition(self,id):
        if id in self.defs:return self.defs[id]
        if id=='PASADA:RFM95W':
            d=standard('RF_Module','RFM95W-868S2');d[1]=id
            for child in d:
                if isinstance(child,list) and child[0]==S('symbol'):child[1]=child[1].replace('RFM95W-868S2_','RFM95W_')
                if isinstance(child,list) and child[0]==S('property') and child[1]=='Value':child[2]='RFM95W'
                if isinstance(child,list) and child[0]==S('property') and child[1]=='Datasheet':child[2]='https://www.hoperf.com/uploads/RFM95W-V2.0_1695351437.pdf'
        elif id.startswith('PASADA:'):d=copy.deepcopy(CUSTOM[id])
        else:d=standard(*id.split(':',1))
        if id=='PASADA:RFM95W':
            def scale(node):
                if not isinstance(node,list):return
                if node and node[0] in [S('at'),S('start'),S('end'),S('mid'),S('xy')]:
                    node[1]=round(node[1]*2,6);node[2]=round(node[2]*2,6)
                if node and node[0]==S('length'):node[1]=round(node[1]*2,6)
                if node and node[0]==S('size'):node[1:3]=[1.6,1.6]
                for child in node:scale(child)
            scale(d)
        # White, unfilled module bodies for a line schematic; retain native electrical symbols.
        def clean(node):
            if not isinstance(node,list):return
            if node and node[0]==S('fill') and len(node)>1:node[1]=n('type',S('none'))
            for child in node:clean(child)
        clean(d)
        if id in ['PASADA:CN3065_carrier','PASADA:Protection_1S_common_port','PASADA:TPS63020_carrier','PASADA:MMC5603_breakout']:
            d.insert(2,n('pin_numbers',S('hide')))
        self.defs[id]=d;return d
    def add(self,ref,id,value,x,y,rot=0,proposed=False,refpos=None,valuepos=None):
        d=self.definition(id); ident=u(); px,py=mm(x),mm(y)
        pins={}
        for unit in d:
            if isinstance(unit,list) and unit[0]==S('symbol'):
                for p in unit:
                    if isinstance(p,list) and p[0]==S('pin'):
                        num=str(val(p,'number')); at=item(p,'at')[1:]
                        theta=math.radians(rot);xx=at[0]*math.cos(theta)-at[1]*math.sin(theta);yy=at[0]*math.sin(theta)+at[1]*math.cos(theta)
                        pins[num]={'xy':(round((px+xx)/G,6),round((py-yy)/G,6)),
                                   'name':val(p,'name'),'type':str(p[1])}
        c=n('symbol',n('lib_id',id),n('at',px,py,rot),n('unit',1),n('in_bom',S('yes')),
            n('on_board',S('yes')),n('dnp',S('yes') if 'DNP' in value else S('no')),n('uuid',ident))
        if refpos is None:refpos=(x+3,y-3)
        if valuepos is None:valuepos=(x+3,y-1)
        for i,(k,v,pos) in enumerate([('Reference',ref,refpos),('Value',value,valuepos),('Footprint','',(x,y)),('Datasheet',val(next((t for t in d if isinstance(t,list) and t[0]==S('property') and t[1]=='Datasheet'),[]),'x',''),(x,y))]):
            if k=='Datasheet':v=next((t[2] for t in d if isinstance(t,list) and t[0]==S('property') and t[1]=='Datasheet'),'')
            field_angle=90 if rot%180==90 else 0
            c.append(n('property',k,v,n('id',i),n('at',mm(pos[0]),mm(pos[1]),field_angle),
                       fx(1.6 if i else 1.8,hide=i>=2 or (i==0 and ref.startswith('#')))))
        for num in pins:c.append(n('pin',num,n('uuid',u())))
        c.append(n('instances',n('project',self.name,n('path','/'+self.id,n('reference',ref),n('unit',1)))))
        self.objects.append(c);self.parts[ref]={'ref':ref,'id':id,'value':value,'pins':pins,'proposed':proposed}
        return ref
    def p(self,ref,pin):return self.parts[ref]['pins'][str(pin)]['xy']
    def wire(self,*points):
        for a,b in zip(points,points[1:]):
            if a==b:continue
            assert abs(a[0]-b[0])<1e-5 or abs(a[1]-b[1])<1e-5,(a,b)
            self.objects.append(n('wire',n('pts',n('xy',mm(a[0]),mm(a[1])),n('xy',mm(b[0]),mm(b[1]))),
                n('stroke',n('width',0),n('type',S('default'))),n('uuid',u())))
    def dot(self,xy):
        if xy in self.dots:return
        self.dots.add(xy);self.objects.append(n('junction',n('at',mm(xy[0]),mm(xy[1])),n('diameter',0),n('color',0,0,0,0),n('uuid',u())))
    def label(self,text,xy,angle=0):
        self.objects.append(n('label',text,n('at',mm(xy[0]),mm(xy[1]),angle),fx(1.5,'left'),n('uuid',u())))
    def nc(self,ref,pin):
        p=self.p(ref,pin);self.objects.append(n('no_connect',n('at',mm(p[0]),mm(p[1])),n('uuid',u())))
    def text(self,t,x,y,size=1.27):
        self.objects.append(n('text',t,n('at',mm(x),mm(y),0),fx(size,'left'),n('uuid',u())))
    def ground(self,xy):
        ref='#PWR'+str(sum(k.startswith('#PWR') for k in self.parts)+1)
        self.add(ref,'power:GND','GND',*xy,refpos=xy,valuepos=(xy[0],xy[1]+2.8))
    def power(self,ref,pin,net,dx=-4):
        p=self.p(ref,pin);q=(p[0]+dx,p[1]);self.wire(p,q);self.label(net,q)
    def finish(self,notes):
        self.text('PASADA | '+self.title,8,8,2.2)
        self.text('P1 - PROTOTYPE REVIEW | header labels identify modules; IC pad numbers identify bare parts.',8,12,1.27)
        for i,line in enumerate(notes):self.text(line,8,103+i*2.4,1.4)
        # KiCad's electrical graph requires explicit segment endpoints at T junctions.
        # Split at intended junctions, labels, pins and wire ends; interior crossings
        # without a junction remain unconnected.
        lines=[];points=set()
        for obj in self.objects:
            if obj[0]==S('wire'):
                ab=[tuple(t[1:]) for t in item(obj,'pts')[1:]]
                lines.append(ab);points.update(ab)
            elif obj[0] in [S('junction'),S('label')]:
                points.add(tuple(item(obj,'at')[1:3]))
        for part in self.parts.values():
            for pin in part['pins'].values():points.add(tuple(mm(c) for c in pin['xy']))
        self.objects=[o for o in self.objects if o[0]!=S('wire')]
        unique=set()
        for a,b in lines:
            split=[]
            for p in points:
                on=(abs(a[0]-b[0])<1e-6 and abs(p[0]-a[0])<1e-6 and min(a[1],b[1])-1e-6<=p[1]<=max(a[1],b[1])+1e-6) or (abs(a[1]-b[1])<1e-6 and abs(p[1]-a[1])<1e-6 and min(a[0],b[0])-1e-6<=p[0]<=max(a[0],b[0])+1e-6)
                if on:split.append(p)
            split=sorted(set(split),key=lambda p:(p[0]-a[0])**2+(p[1]-a[1])**2)
            for p,q in zip(split,split[1:]):
                key=tuple(sorted([p,q]))
                if key in unique:continue
                unique.add(key)
                self.objects.append(n('wire',n('pts',n('xy',*p),n('xy',*q)),n('stroke',n('width',0),n('type',S('default'))),n('uuid',u())))
        root=n('kicad_sch',n('version',20230121),n('generator',S('eeschema')),n('uuid',self.id),n('paper','A3'),
            n('title_block',n('title',self.title),n('date','2026-10-31'),n('rev','P1'),
              n('company','PASADA / LEAR - engineering review'),n('comment',1,'Manually routed. Not a field-installation release.')),
            n('lib_symbols',*self.defs.values()),*self.objects,n('sheet_instances',n('path','/',n('page','1'))))
        out=ROOT/'kicad';out.mkdir(parents=True,exist_ok=True)
        path=out/(self.name+'.kicad_sch');path.write_text(sx.dumps(root),encoding='utf-8')
        return path

def puck():
    s=Sheet('01_sensor_puck','01  SENSOR / SOLAR PUCK')
    s.add('PV101','Device:Solar_Cell','5.5 V / 90-100 mA',14,24,refpos=(14,17),valuepos=(14,19))
    s.add('U101','PASADA:CN3065_carrier','CN3065 carrier',36,24,refpos=(36,14),valuepos=(36,16))
    s.add('U102','PASADA:Protection_1S_common_port','1S protection*',66,24,refpos=(66,14),valuepos=(66,16))
    s.add('BT101','Device:Battery_Cell','1S LiPo 803450',88,25,refpos=(90,19),valuepos=(95,21))
    s.add('U103','PASADA:TPS63020_carrier','TPS63020 / 3.3 V',121,24,refpos=(121,14),valuepos=(121,16))
    p=s.p('PV101','1');s.wire(p,(14,18),(21,18),(21,22),s.p('U101','IN+'))
    p=s.p('PV101','2');s.wire(p,(14,40))
    s.wire(s.p('U101','IN-'),(23,27),(23,40))
    s.wire(s.p('U101','BAT+'),s.p('U102','P+'))
    s.wire(s.p('U101','BAT-'),(47,40))
    s.wire(s.p('U102','P-'),(55,40))
    s.wire(s.p('U102','B+'),(83,22),(83,23),s.p('BT101','1'))
    s.wire(s.p('U102','B-'),(88,27),s.p('BT101','2'))
    s.label('CELL_NEG',(82,27))
    s.wire((51,22),(51,10),(105,10),(105,22),s.p('U103','IN+'));s.dot((51,22));s.label('BAT_PROTECTED',(73,10))
    s.wire(s.p('U103','IN-'),(108,27),(108,40))
    s.wire(s.p('U103','OUT-'),(139,27),(139,40))
    s.wire((14,40),(139,40));
    for x in [23,47,55,108]:s.dot((x,40))
    s.ground((100,40));s.dot((100,40))
    s.add('JP101','Jumper:Jumper_2_Bridged','RUN link',141,22,refpos=(141,17),valuepos=(141,19))
    s.wire(s.p('U103','OUT+'),s.p('JP101','1'))
    s.wire(s.p('JP101','2'),(151,22),(151,58),(18,58));s.label('+3V3_SENSOR',(145,22))
    # The SS12D06's common must be identified by continuity, not assumed from a vendor clone.
    s.add('SW101','Switch:SW_SPDT','SS12D06 - EN only',113,47,180,refpos=(112,43),valuepos=(112,45))
    s.add('R101','Device:R','1k',123,47,90,refpos=(123,43),valuepos=(123,45))
    s.wire(s.p('SW101','2'),s.p('R101','1'))
    p=s.p('SW101','1');s.wire(p,(100,p[1]));s.label('BAT_PROTECTED',(100,p[1]))
    p=s.p('SW101','3');s.wire(p,(100,p[1]));s.label('GND',(100,p[1]))
    s.wire(s.p('R101','2'),(133,47),(133,36),(121,36),s.p('U103','EN'))
    s.add('R102','Device:R','100k',141,47,refpos=(145,46),valuepos=(145,48))
    s.wire(s.p('R102','1'),(141,36),(133,36));s.dot((133,36))
    s.wire(s.p('R102','2'),(141,53));s.ground((141,53))
    s.text('* EN pad/link inspection required before SW101 is connected.',62,54,1.2)
    s.add('U104','PASADA:C3_SuperMini_EXT3V3','ESP32-C3 SuperMini',48,80,refpos=(48,63),valuepos=(48,65))
    s.add('U105','PASADA:MMC5603_breakout','PCBfun MMC5603',108,74.5,refpos=(122,63),valuepos=(122,65))
    for gp,target in [('6','SDA'),('7','SCL')]:s.wire(s.p('U104',gp),s.p('U105',target))
    # MCU left-hand power pins are the actual labeled module terminals.
    p=s.p('U104','3V3');s.wire(p,(28,p[1]),(28,58));s.dot((28,58))
    s.power('U104','GND','GND',-6)
    s.wire(s.p('U105','VIN'),(108,58));s.dot((108,58))
    s.wire(s.p('U105','GND'),(108,98));s.ground((108,98))
    for pin in ['5V','4','3','2','1','0','5','8','9','10','20','21']:s.nc('U104',pin)
    s.nc('U105','3Vo')
    for ref,x,cap,kind in [('C101',18,'100nF','C'),('C102',25,'10uF / 16V','C_Polarized'),('C103',132,'100nF','C'),('C104',145,'220uF / 16V DNP','C_Polarized')]:
        rp=(15,80) if ref=='C101' else (29,80) if ref=='C102' else (x+3,81)
        vp=(15,87) if ref=='C101' else (29,87) if ref=='C102' else (x+6,84)
        s.add(ref,'Device:'+kind,cap,x,83,refpos=rp,valuepos=vp)
        s.wire(s.p(ref,'1'),(x,58));s.dot((x,58))
        s.wire(s.p(ref,'2'),(x,98));s.ground((x,98))
    # Optional pullups are only fitted if carrier pullups are absent/unsuitable.
    for ref,x,netpin in [('R103',76,'6'),('R104',88,'7')]:
        s.add(ref,'Device:R','4.7k DNP',x,65,refpos=(x+3,63),valuepos=(x+5,66))
        s.wire(s.p(ref,'1'),(x,58));s.dot((x,58))
        y=s.p('U104',netpin)[1];s.wire(s.p(ref,'2'),(x,y));s.dot((x,y))
    s.text('Remove JP101 before USB-powered programming; no external source into the 5V pin.',8,49,1.4)
    s.finish(['1. Verify carrier pads, 3.30 V output and EN access. SS12D06 controls EN only.',
        '2. Fit U102 only when needed for protection. Charger/load returns use P-; CELL_NEG stays separate.',
        '3. CN3065: input <=6 V including panel Voc. Verify charge current, temperature protection and charging under load.'])
    return s

def beacon():
    s=Sheet('02_emergency_beacon','02  EMERGENCY VEHICLE BEACON')
    s.text('PROPOSED GPS: Adafruit Ultimate GPS v3 #746. Power through U201 onboard USB-C only (regulated 5 V USB).',8,18,1.3)
    s.add('U201','PASADA:C3_SuperMini_USB','ESP32-C3 SuperMini',57,60,refpos=(57,43),valuepos=(57,45))
    s.add('U202','PASADA:Ultimate_GPS_v3','Ultimate GPS v3 #746',112,72,0,True,
          refpos=(128,57),valuepos=(128,60))
    # Header JP1 numbering comes from the original manufacturer board CAD.
    s.wire(s.p('U201','20'),s.p('U202','5'))
    s.wire(s.p('U201','21'),s.p('U202','4'))
    s.label('GPS_TX__MCU_RX',(79,67.5));s.label('MCU_TX__GPS_RX',(79,70.5))
    p=s.p('U201','5V');s.wire(p,(37,p[1]),(37,30),(112,30),s.p('U202','2'));s.label('+5V_USB',(88,30))
    p=s.p('U201','3V3');s.wire(p,(31,p[1]),(31,36),(42,36));s.label('+3V3_MCU',(34,36))
    p=s.p('U201','GND');s.wire(p,(41,p[1]),(41,94));s.ground((41,94))
    s.wire(s.p('U202','3'),(112,94));s.ground((112,94))
    for pin in ['1','6','7','8','9']:s.nc('U202',pin)
    # Active-low emergency-enable contact with explicit pullup and debounce capacitor.
    s.add('R201','Device:R','10k',25,57,refpos=(21,56),valuepos=(21,58))
    s.wire(s.p('R201','1'),(25,36),(31,36));s.dot((31,36))
    en=s.p('U201','0');s.wire(en,(25,en[1]),s.p('R201','2'));s.dot((25,en[1]));s.label('EMERGENCY_EN_N',(26,en[1]))
    s.add('SW201','Switch:SW_SPST','Emergency enable',25,84,90,refpos=(32,81),valuepos=(32,85))
    s.wire((25,en[1]),s.p('SW201','1'));s.wire(s.p('SW201','2'),(25,94));s.ground((25,94))
    s.add('C201','Device:C','100nF',14,84,refpos=(9,82),valuepos=(9,86))
    s.wire(s.p('C201','1'),(14,en[1]),(25,en[1]));s.wire(s.p('C201','2'),(14,94));s.ground((14,94))
    s.add('R202','Device:R','1k',145,76,refpos=(149,75),valuepos=(149,77))
    s.add('D201','Device:LED','Active status',145,86,90,refpos=(151,84),valuepos=(152,87))
    s.power('U201','3','STATUS_LED',-10)
    p=s.p('R202','1');s.wire(p,(145,71),(141,71));s.label('STATUS_LED',(141,71))
    s.wire(s.p('R202','2'),s.p('D201','2'));s.wire(s.p('D201','1'),(145,94));s.ground((145,94))
    for ref,x,cap,rail in [('C202',79,'100nF','+3V3_MCU'),('C203',88,'10uF / 16V','+3V3_MCU'),('C204',132,'10uF / 16V','+5V_USB')]:
        kind='C' if cap=='100nF' else 'C_Polarized'
        s.add(ref,'Device:'+kind,cap,x,84,refpos=(x+3,82),valuepos=(x+5,86))
        p=s.p(ref,'1');s.wire(p,(x,78));s.label(rail,(x,78))
        s.wire(s.p(ref,'2'),(x,94));s.ground((x,94))
    for pin in ['4','2','1','5','6','7','8','9','10']:s.nc('U201',pin)
    s.text('ESP-NOW uses the onboard 2.4 GHz antenna; no LoRa module is needed on this beacon.',76,47,1.27)
    s.text('GPS EN is already pulled up on the carrier; optional backup cell and unused outputs are left open.',76,51,1.13)
    s.finish(['1. GPS TX(5) -> GPIO20 RX; GPIO21 TX -> GPS RX(4). Use UART0 for GPS and native USB for logs.',
        '2. SW201 is a firmware request. GPIO2/8/9 stay unloaded; signal safety remains with the coordinator.',
        '3. Use regulated 5 V USB from a bench or protected vehicle adapter. Keep raw 12/24 V outside this circuit.'])
    return s

def coordinator():
    s=Sheet('03_intersection_coordinator','03  INTERSECTION COORDINATOR')
    s.text('Power through U301 onboard USB-C only. Proposed DS3231SN + separate AP2112K-3.3 supply for RFM95W.',8,18,1.3)
    s.add('U301','PASADA:C3_SuperMini_USB','ESP32-C3 SuperMini',65,77,refpos=(65,60),valuepos=(65,62))
    s.add('U302','PASADA:RFM95W','RFM95W (band TBD)',116,72,
          refpos=(128,56),valuepos=(128,58))
    # Native HopeRF symbol; pad 13=VCC and pad 14=DIO0, not pad 16=VCC.
    for gp,pad,track in [('5','4',86),('6','3',88),('7','2',90),('10','5',92)]:
        a=s.p('U301',gp);b=s.p('U302',pad);s.wire(a,(track,a[1]),(track,b[1]),b)
    for gp,pad,label in [('3','6','RF_RESET_N'),('4','14','RF_IRQ_DIO0')]:
        s.power('U301',gp,label,-9);s.power('U302',pad,label,-11 if pad=='6' else 9)
    for pad in ['7','11','12','15','16']:s.nc('U302',pad)
    for pad in ['1','8','10']:
        p=s.p('U302',pad);s.wire(p,(p[0],84))
    s.wire((114,84),(118,84));s.dot((116,84));s.wire((116,84),(116,87));s.ground((116,87))
    s.add('J301','Connector:Conn_Coaxial','50 ohm antenna',146,69,refpos=(146,64),valuepos=(146,66))
    s.wire(s.p('U302','9'),(136,66),(136,69),s.p('J301','1'));s.wire(s.p('J301','2'),(146,77));s.ground((146,77))
    # Separate, fully shown 5-pin regulator: VIN1, GND2, EN3, NC4, VOUT5.
    s.add('U303','Regulator_Linear:AP2112K-3.3','AP2112K-3.3',111,35,0,True,
          refpos=(111,29),valuepos=(111,31))
    p=s.p('U301','5V');s.wire(p,(46,p[1]),(46,24),(98,24),(98,34),s.p('U303','1'));s.label('+5V_USB',(78,24))
    s.wire(s.p('U303','3'),(98,35),(98,34));s.dot((98,34));s.nc('U303','4')
    s.wire(s.p('U303','2'),(111,44));s.ground((111,44))
    p=s.p('U303','5');s.wire(p,(149,34),(149,54),(116,54),s.p('U302','13'));s.label('+3V3_RF',(127,34));s.dot((116,54))
    for ref,x,cap,rail in [('C301',92,'1uF X7R','+5V_USB'),('C302',134,'1uF X7R','+3V3_RF'),('C303',143,'10uF / 16V','+3V3_RF'),('C304',153,'100nF','+3V3_RF')]:
        kind='C_Polarized' if '16V' in cap else 'C'
        s.add(ref,'Device:'+kind,cap,x,43,refpos=(x+3,42),valuepos=(x+5,45))
        p=s.p(ref,'1');s.wire(p,(x,38));s.label(rail,(x,38))
        s.wire(s.p(ref,'2'),(x,49));s.ground((x,49))
    s.power('U301','3V3','+3V3_MCU',-7)
    s.power('U301','GND','GND',-8)
    # RTC on a passive SOIC-16 adapter. No commercial charging breakout is assumed.
    s.add('U304','PASADA:DS3231SN','DS3231SN / SOIC16',25,77,0,True,refpos=(35,56),valuepos=(35,59))
    for gp,pad in [('1','16'),('0','15')]:s.wire(s.p('U304',pad),s.p('U301',gp))
    for pin in ['1','3','4']:s.nc('U304',pin)
    for pin in [str(i) for i in range(5,13)]:
        p=s.p('U304',pin);s.wire(p,(11,p[1]));s.dot((11,p[1]))
    s.wire((11,67),(11,96));s.ground((11,96))
    p=s.p('U304','13');s.wire(p,(25,96));s.ground((25,96))
    s.power('U304','2','+3V3_MCU',-6)
    s.add('BT301','Device:Battery_Cell','CR2032 / 3 V',20,43,refpos=(17,38),valuepos=(16,40))
    s.wire(s.p('BT301','1'),(30,41),(30,55),(27,55),s.p('U304','14'))
    s.wire(s.p('BT301','2'),(20,49));s.ground((20,49))
    s.add('C305','Device:C','100nF',36,45,refpos=(40,44),valuepos=(40,46));s.power('C305','1','+3V3_MCU',-4)
    s.wire(s.p('C305','2'),(36,51));s.ground((36,51))
    for ref,x,pad in [('R301',38,'15'),('R302',43,'16')]:
        s.add(ref,'Device:R','4.7k',x,96,refpos=(x+3,94),valuepos=(x+3,96))
        p=s.p(ref,'1');y=s.p('U304',pad)[1];s.wire(p,(x,y));s.dot((x,y))
        p=s.p(ref,'2');s.wire(p,(x,99))
    s.wire((38,99),(48,99));s.dot((43,99));s.label('+3V3_MCU',(44,99))
    s.add('R303','Device:R','10k',94,91,refpos=(90,90),valuepos=(90,92))
    p=s.p('R303','1');y=s.p('U301','10')[1];s.wire(p,(94,y),(92,y));s.dot((92,y))
    p=s.p('R303','2');s.wire(p,(94,96),(92,96));s.label('+3V3_MCU',(92,96))
    s.add('R304','Device:R','10k',102,91,refpos=(106,90),valuepos=(106,92))
    s.power('R304','1','RF_RESET_N',-4)
    p=s.p('R304','2');s.wire(p,(102,96),(100,96));s.label('+3V3_RF',(100,96))
    for pin in ['2','8','9']:s.nc('U301',pin)
    # Logic-only handoff port. No invented cabinet or mains terminal assignment.
    s.add('J302','PASADA:Logic_port_4','3V3 service / gateway',70,39,refpos=(70,29),valuepos=(70,31))
    s.power('J302','1','+3V3_MCU',-5)
    s.power('J302','2','GND',-7)
    for gp,pin,label in [('21','3','GATEWAY_TX'),('20','4','GATEWAY_RX')]:
        s.power('U301',gp,label,7);s.power('J302',pin,label,-9)
    s.text('J302 is low-voltage UART only. Cabinet isolation / protocol / fail-safe handback must be specified separately.',57,98,1.13)
    s.finish(['1. I2C SDA/SCL=GPIO0/1. SPI SCK/MOSI/MISO/NSS=GPIO5/6/7/10. RF reset/IRQ=GPIO3/4.',
        '2. DS3231SN pads 5-12 -> GND. CR2032 is not charged. MCU and RF regulator outputs remain separate.',
        '3. Match RFM95W band and antenna. Use RF breakout/coax. Cabinet protocol and isolation remain to be specified.'])
    return s

def main():
    ROOT.mkdir(exist_ok=True)
    sheets=[puck(),beacon(),coordinator()]
    bom=[]
    for sh in sheets:
        for part in sh.parts.values():
            if not part['ref'].startswith('#'):
                bom.append({'sheet':sh.name,'reference':part['ref'],'value':part['value'],
                            'symbol':part['id'],'selection':'PROPOSED' if part['proposed'] else 'selected/support',
                            'pin_ids':'; '.join(f"{k}={p['name']}" for k,p in part['pins'].items())})
    with (ROOT/'BOM_and_pins.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(bom[0]));w.writeheader();w.writerows(bom)
    (ROOT/'design_manifest.json').write_text(json.dumps({'revision':'P1','date':'2026-10-31',
        'tool':'KiCad 7 native schematics, manually routed from explicit net connections',
        'sheets':[s.name for s in sheets],'parts':bom},indent=2))
    print(json.dumps({'sheets':[s.name for s in sheets],'parts':len(bom)}))

if __name__=='__main__':main()

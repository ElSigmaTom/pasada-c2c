"""KiCad parses the sources; connectivity assertions inspect its exported netlists."""
import csv,json,os,shutil,subprocess
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parent
runtime=ROOT.parent/'kicad_runtime'
CLI=shutil.which('kicad-cli') or str(runtime/'usr/bin/kicad-cli')
ENV=dict(os.environ)
if runtime.exists():ENV['LD_LIBRARY_PATH']=str(runtime/'usr/lib/x86_64-linux-gnu')+':'+str(runtime/'usr/lib/x86_64-linux-gnu/kicad')
def run(args):
    p=subprocess.run([CLI,*args],env=ENV,capture_output=True,text=True)
    if p.returncode:raise RuntimeError(p.stdout+'\n'+p.stderr)
    return p.stdout
def exports():
    for f in ['svg','netlists','qa']:(ROOT/f).mkdir(exist_ok=True)
    for sch in sorted((ROOT/'kicad').glob('*.kicad_sch')):
        run(['sch','export','pdf','--black-and-white','--no-background-color','-o',str(ROOT/(sch.stem+'.pdf')),str(sch)])
        run(['sch','export','svg','--no-background-color','-o',str(ROOT/'svg')+'/',str(sch)])
        run(['sch','export','netlist','--format','kicadxml','-o',str(ROOT/'netlists'/(sch.stem+'.xml')),str(sch)])
        pop='/usr/bin/pdftoppm' if Path('/usr/bin/pdftoppm').exists() else 'pdftoppm'
        subprocess.run([pop,'-scale-to','2200','-png','-singlefile',str(ROOT/(sch.stem+'.pdf')),str(ROOT/'qa'/sch.stem)],check=True)

def merge():
    from pypdf import PdfReader,PdfWriter
    out=ROOT/'output/pdf';out.mkdir(parents=True,exist_ok=True)
    w=PdfWriter()
    for i,stem in enumerate(['01_sensor_puck','02_emergency_beacon','03_intersection_coordinator']):
        r=PdfReader(ROOT/(stem+'.pdf'));assert len(r.pages)==1
        w.add_page(r.pages[0]);w.add_outline_item(stem.replace('_',' '),i)
    w.add_metadata({'/Title':'PASADA - Sensor, Beacon and Coordinator Wiring Schematics P1',
        '/Author':'PASADA project','/Subject':'Manually wired KiCad prototype schematics; no field release'})
    with (out/'PASADA_Wiring_Schematics_P1.pdf').open('wb') as f:w.write(f)

def audit():
    result=[];allrows=[]
    for f in sorted((ROOT/'netlists').glob('*.xml')):
        tree=ET.parse(f).getroot();nets={};by_pin={}
        for net in tree.findall('./nets/net'):
            name=net.get('name');nodes={(x.get('ref'),x.get('pin')) for x in net.findall('node')}
            nets[name]=nodes
            for node in nodes:by_pin[node]=name
            for node in sorted(nodes):allrows.append({'sheet':f.stem,'net':name,'reference':node[0],'pin_id':node[1]})
        checks=[]
        def same(label,*pins):
            names=[by_pin.get(p) for p in pins]
            passed=bool(names[0]) and len(set(names))==1
            checks.append({'check':label,'passed':passed,'pins':pins,'nets':names})
        def different(label,*pins):
            names=[by_pin.get(p) for p in pins]
            checks.append({'check':label,'passed':all(names) and len(set(names))==len(names),'pins':pins,'nets':names})
        def singleton(label,pin):
            net=by_pin.get(pin)
            checks.append({'check':label,'passed':bool(net) and nets[net]=={pin},'pins':[pin],'nets':[net]})
        if f.stem.startswith('01_'):
            same('Sensor SDA',('U104','6'),('U105','SDA'),('R103','2'))
            same('Sensor SCL',('U104','7'),('U105','SCL'),('R104','2'))
            same('Regulated load supply',('JP101','2'),('U104','3V3'),('U105','VIN'),('C101','1'),('C102','1'),('R103','1'),('R104','1'))
            same('Regulator to removable run link',('U103','OUT+'),('JP101','1'))
            same('Protected battery supply',('U101','BAT+'),('U102','P+'),('U103','IN+'),('SW101','1'))
            same('All system returns on protected side',('U102','P-'),('U101','IN-'),('U101','BAT-'),('U103','IN-'),('U103','OUT-'),('U104','GND'),('U105','GND'))
            same('Cell negative enters protection only',('BT101','2'),('U102','B-'))
            different('Cell negative is not system ground',('BT101','2'),('U104','GND'))
            same('Cell positive enters protection',('BT101','1'),('U102','B+'))
            same('Switch common through series resistor',('SW101','2'),('R101','1'))
            same('Enable node',('R101','2'),('U103','EN'),('R102','1'))
            same('Enable OFF / pulldown return',('SW101','3'),('R102','2'),('U104','GND'))
            singleton('Module 5V not externally driven',('U104','5V'))
        elif f.stem.startswith('02_'):
            same('GPS TX to MCU RX',('U202','5'),('U201','20'))
            same('MCU TX to GPS RX',('U201','21'),('U202','4'))
            same('USB5V feeds GPS VIN',('U201','5V'),('U202','2'),('C204','1'))
            same('3V3 pullup and local decoupling',('U201','3V3'),('R201','1'),('C202','1'),('C203','1'))
            same('Active-low emergency contact',('U201','0'),('R201','2'),('SW201','1'),('C201','1'))
            same('All beacon returns',('U201','GND'),('U202','3'),('SW201','2'),('C201','2'),('D201','1'))
            different('GPS onboard regulator output not tied to MCU regulator',('U202','9'),('U201','3V3'))
            same('LED series resistor',('U201','3'),('R202','1'))
            same('LED anode after resistor',('R202','2'),('D201','2'))
        else:
            same('SPI SCK',('U301','5'),('U302','4'))
            same('SPI MOSI',('U301','6'),('U302','3'))
            same('SPI MISO',('U301','7'),('U302','2'))
            same('SPI NSS with pullup',('U301','10'),('U302','5'),('R303','1'))
            same('Radio reset',('U301','3'),('U302','6'),('R304','1'))
            same('Radio IRQ pad14',('U301','4'),('U302','14'))
            same('RTC SDA',('U301','0'),('U304','15'),('R301','1'))
            same('RTC SCL',('U301','1'),('U304','16'),('R302','1'))
            same('RTC 3V3 and pullups',('U301','3V3'),('U304','2'),('R301','2'),('R302','2'),('R303','2'),('J302','1'))
            same('Radio supply is regulator output to pad13',('U303','5'),('U302','13'),('R304','2'),('C302','1'),('C303','1'),('C304','1'))
            different('Two 3V3 regulator outputs not shorted',('U301','3V3'),('U303','5'))
            same('RF regulator input and enable',('U301','5V'),('U303','1'),('U303','3'),('C301','1'))
            same('RTC backup battery',('BT301','1'),('U304','14'))
            different('RTC coin cell not tied to VCC',('U304','14'),('U304','2'))
            same('RTC NC pads grounded',('U304','13'),*[( 'U304',str(i)) for i in range(5,13)])
            same('All radio grounds',('U302','1'),('U302','8'),('U302','10'),('U301','GND'),('U303','2'),('U304','13'),('BT301','2'))
            same('RF centre pin',('J301','1'),('U302','9'))
            same('RF coax shield',('J301','2'),('U301','GND'))
            same('Service TX',('J302','3'),('U301','21'))
            same('Service RX',('J302','4'),('U301','20'))
            different('NSS and gateway TX stay separate',('U301','10'),('U301','21'))
        mcu='U104' if f.stem.startswith('01_') else 'U201' if f.stem.startswith('02_') else 'U301'
        for pin in ['2','8','9']:singleton('No external load on strap GPIO'+pin,(mcu,pin))
        result.append({'sheet':f.stem,'checks':checks,'passed':all(x['passed'] for x in checks)})
    with (ROOT/'wire_connections.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0]));w.writeheader();w.writerows(allrows)
    report={'tool':'KiCad 7.0.11 native schematic parser and exported XML netlist',
            'scope':'Connectivity assertions only; not a full ERC or physical electrical validation.',
            'sheets':result,'passed':all(x['passed'] for x in result)}
    (ROOT/'connectivity_audit.json').write_text(json.dumps(report,indent=2))
    for sheet in result:
        for check in sheet['checks']:
            if not check['passed']:print('FAILED',sheet['sheet'],check)
    print(json.dumps({'checks':sum(len(x['checks']) for x in result),'passed':report['passed']}))
    assert report['passed'],'Fix reported connectivity errors before delivery.'

if __name__=='__main__':
    exports();audit();merge()
